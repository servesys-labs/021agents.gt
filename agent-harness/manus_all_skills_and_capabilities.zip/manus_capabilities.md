# Manus: Comprehensive Capabilities Guide

As Manus, an autonomous general AI agent, my capabilities extend far beyond a few specific modular skills. I am designed to operate in a sandboxed virtual machine environment with full internet access, allowing me to accomplish open-ended objectives through step-by-step iteration. 

This document outlines the full spectrum of my capabilities, categorized into core built-in functions, integrated tools, system utilities, and modular skill extensions.

## 1. Core Built-In Capabilities

My fundamental abilities allow me to act as a versatile assistant, researcher, developer, and creator.

### Research & Information Gathering
I can conduct in-depth research across multiple sources, synthesize findings, and check facts. I do not rely solely on internal knowledge; I actively search the live web for up-to-date information, articles, news, and academic research. I can access and interpret web pages directly to extract relevant content.

### Data Processing & Analysis
I am equipped to process structured and unstructured data. I can analyze datasets, perform complex calculations (using Python), and create insightful visualizations (charts, graphs) or spreadsheets. I can also extract data from public datasets, dashboards, or downloadable tables.

### Writing & Content Creation
I produce comprehensive documents, multi-chapter articles, and in-depth research reports grounded in credible sources. My writing spans technical, academic, and creative domains. I can also prepare and generate slide-based presentations (PPT/PPTX) in both editable HTML and visually stunning image formats.

### Web & App Development
I can build well-crafted websites, interactive applications, and practical software solutions. I can initialize new web or mobile app projects with automated environment setup and hosting services, including static sites, database-backed user apps, and native mobile apps (React Native/Expo).

### Media Generation & Editing
I possess advanced AI capabilities to generate and edit various forms of media:
- **Images**: Create visual content from text descriptions, edit existing images, and generate assets like posters or infographics.
- **Video & Audio**: Generate video content, audio tracks, music, and speech from text and media references.
- **Music**: Synthesize original songs, soundtracks, and instrumental tracks based on detailed emotional and structural prompts.

### Programming & Automation
I apply programming to solve real-world problems beyond standard development. I can write, execute, and debug code (Python, Node.js, bash) directly in my environment. I can automate workflows, interact with APIs, and schedule tasks to run at specific times or recurring intervals using cron or interval scheduling.

### Browser Automation
I can log in and maintain authentication state to perform browser automation on your behalf. This allows me to navigate web applications, submit forms, make purchases, and collaborate with you to automate complex online workflows.

### Parallel Processing
For large-scale tasks, I can spawn up to 2000 parallel subtasks to process data, conduct broad research, or perform repetitive operations efficiently.

## 2. Integrated Tools & System Environment

I operate within a robust Ubuntu 22.04 Linux environment with sudo privileges, allowing me to install additional software and dependencies as needed.

### File System Operations
I can view, read, write, append, and edit files in various formats (Markdown, PDF, Word, Excel, PowerPoint, code files, images). I use pattern matching to find files or search file contents using regex.

### Shell Interaction
I have direct access to a bash shell, enabling me to execute commands, manage processes, manipulate files, and interact with the operating system.

### Model Context Protocol (MCP) Integrations
I can interact with external services through configured MCP servers. Currently, I have integration with **Gmail**, allowing me to:
- Search and list Gmail messages.
- Read email threads.
- Send messages or save them as drafts.
- Manage Gmail labels.

### GitHub Integration
I am pre-configured with the GitHub CLI (`gh`), allowing me to clone repositories, create new private repositories, and manage code collaboration seamlessly.

## 3. Command Line Utilities

My environment includes several pre-installed custom utilities to enhance my capabilities:

- **Diagram Rendering**: Convert diagram files (D2, Mermaid, PlantUML) to PNG format (`manus-render-diagram`).
- **PDF Conversion**: Convert Markdown files to PDF (`manus-md-to-pdf`).
- **Speech-to-Text**: Transcribe speech and audio files (MP3, WAV, MP4) to text (`manus-speech-to-text`).
- **File Upload**: Upload files to S3 to get direct public URLs for external API invocations (`manus-upload-file`).
- **Slide Export**: Export generated slide presentations to PDF or PPT formats (`manus-export-slides`).
- **Video Analysis**: Analyze video content (YouTube, remote, or local files) using a multi-modality LLM (`manus-analyze-video`).

## 4. Modular Skill Extensions

In addition to my core capabilities, I have specialized "Skills" — modular packages that provide specific procedural knowledge, workflows, and templates for complex domains.

### bgm-prompter
A specialized guide for crafting highly effective music generation prompts. It provides a 9-dimension framework (Genre, Tempo, Key, Mood, Instrumentation, Density, Structure, Soundscape, Production Quality) and strategies for creating cohesive multi-clip songs exceeding the standard duration limits.

### expo-react-native-app
A comprehensive, battle-tested guide for building production-quality React Native mobile applications using Expo SDK 54+. It includes architecture patterns, dual-theme systems, React Navigation setup, shared component designs, and critical migration knowledge for updating from older SDK versions.

### skill-creator
A meta-skill that provides instructions and workflows for creating new modular skills. It ensures that new capabilities are added in a structured, token-efficient manner, utilizing progressive disclosure patterns and standardized initialization scripts.

---

*This document represents a snapshot of my current capabilities. As an autonomous agent, I am constantly adapting and can learn to utilize new tools and approaches to achieve your goals.*
