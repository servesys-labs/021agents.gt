---
name: expo-react-native-app
description: Comprehensive guide for building production-quality React Native mobile applications using Expo SDK 54+ with TypeScript, React Navigation, dual-theme systems, and shared component patterns. Includes critical SDK migration knowledge (52→54), React 19 TypeScript fixes, and fintech/crypto integration scaffolding. Use this skill when building any Expo mobile app, migrating between SDK versions, or implementing navigation, theming, or Coinbase CDP integrations.
---

# Expo React Native Mobile App Skill

## Overview

This skill provides a battle-tested guide for building React Native mobile applications using Expo SDK 54 (React 19, React Native 0.81). It captures architecture patterns, component design, theming systems, and critical migration knowledge gained from building a 41-screen fintech app (IVISH). The patterns apply broadly to any Expo project but include specialized guidance for fintech, wallet, and P2P payment flows.

## Applicability

Use this skill when the user requests any of the following:

- Building a React Native or Expo mobile application for iOS and/or Android
- Scaffolding a new Expo project with TypeScript, navigation, and theming
- Migrating an existing Expo project to SDK 54 (React 19, React Native 0.81)
- Implementing a dual-theme (dark/light mode) system in React Native
- Setting up React Navigation with stack navigators and bottom tab bars
- Creating a design system with custom fonts, color tokens, and shared components
- Integrating Coinbase Developer Platform or blockchain/crypto features into a mobile app
- Building a fintech app with wallet, payment, and P2P transfer flows

## Phase 1: Project Initialization

### 1.1 Create the Expo Project

Always start with the blank TypeScript template. Do NOT use `expo-router` for apps that need fine-grained control over navigation stacks — use React Navigation instead.

```bash
npx create-expo-app@latest my-app --template blank-typescript
cd my-app
```

### 1.2 Set the Entry Point

For Expo SDK 54, the entry point in `package.json` must be:

```json
{
  "main": "node_modules/expo/AppEntry.js"
}
```

> **Critical:** Do NOT use `"main": "expo-router/entry"` unless you are actually using file-based routing with `expo-router`. Using the wrong entry point causes a blank white screen on launch with no error messages.

### 1.3 Configure Path Aliases

Path aliases (`@/` prefix) dramatically improve import readability. Configure them in two places:

**tsconfig.json:**
```json
{
  "extends": "expo/tsconfig.base",
  "compilerOptions": {
    "strict": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  }
}
```

**babel.config.js:**
```js
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'],
  };
};
```

> **Note:** In Expo SDK 54, `babel-preset-expo` handles the `@/` path alias resolution automatically when `tsconfig.json` paths are configured. You do NOT need `babel-plugin-module-resolver` separately.

### 1.4 Recommended Directory Structure

```
my-app/
├── App.tsx                    # Root component (font loading, providers)
├── app.json                   # Expo configuration
├── babel.config.js            # Babel with reanimated plugin
├── tsconfig.json              # TypeScript with path aliases
├── package.json               # Dependencies
├── assets/                    # Static assets (logos, images)
│   └── logos/
└── src/
    ├── components/            # Shared reusable components
    │   ├── Avatar.tsx
    │   ├── PrimaryButton.tsx
    │   └── ScreenHeader.tsx
    ├── contexts/              # React contexts (Theme, Auth, etc.)
    │   └── ThemeContext.tsx
    ├── lib/                   # Utilities, constants, mock data
    │   ├── theme.ts           # Design tokens (colors, spacing, fonts)
    │   └── mockData.ts        # Development mock data
    ├── navigation/            # Navigation configuration
    │   └── AppNavigator.tsx   # Stack + Tab navigators
    └── screens/               # Screen components (one per file)
        ├── HomeScreen.tsx
        ├── LoginScreen.tsx
        └── ...
```

## Phase 2: Core Dependencies

### 2.1 Expo SDK 54 Compatible Dependencies

These are the exact tested-and-working versions for Expo SDK 54 (as of February 2026). See `references/sdk54_dependency_matrix.md` for the full matrix.

| Package | Version | Purpose |
|---------|---------|---------|
| `expo` | `^54.0.0` | Core Expo SDK |
| `react` | `19.1.0` | React 19 (required by SDK 54) |
| `react-native` | `0.81.5` | React Native 0.81 |
| `@react-navigation/native` | `^7.0.0` | Navigation core |
| `@react-navigation/native-stack` | `^7.2.0` | Native stack navigator |
| `@react-navigation/bottom-tabs` | `^7.2.0` | Bottom tab navigator |
| `react-native-screens` | `~4.16.0` | Native screen containers |
| `react-native-safe-area-context` | `~5.6.0` | Safe area insets |
| `react-native-gesture-handler` | `~2.28.0` | Gesture handling |
| `react-native-reanimated` | `~4.1.1` | Animations |
| `react-native-svg` | `15.12.1` | SVG rendering |
| `expo-font` | `~14.0.11` | Custom font loading |
| `expo-splash-screen` | `~31.0.13` | Splash screen control |
| `expo-status-bar` | `~3.0.9` | Status bar styling |
| `expo-linear-gradient` | `~15.0.8` | Gradient backgrounds |
| `expo-haptics` | `~15.0.8` | Haptic feedback |
| `@expo/vector-icons` | `^15.0.3` | Icon library (Ionicons, etc.) |
| `babel-preset-expo` | `~54.0.10` | Babel preset for SDK 54 |
| `@types/react` | `~19.1.10` | React 19 TypeScript types |
| `typescript` | `^5.3.0` | TypeScript compiler |

Install all at once:

```bash
npx expo install expo-font expo-splash-screen expo-status-bar expo-linear-gradient expo-haptics react-native-gesture-handler react-native-reanimated react-native-safe-area-context react-native-screens react-native-svg @expo/vector-icons

npm install @react-navigation/native @react-navigation/native-stack @react-navigation/bottom-tabs
```

> **Important:** Always use `npx expo install` for Expo-managed packages (those with `~` version ranges) to get SDK-compatible versions. Use `npm install` for community packages.

### 2.2 app.json Configuration

```json
{
  "expo": {
    "name": "MyApp",
    "slug": "my-app",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/logos/icon.png",
    "userInterfaceStyle": "automatic",
    "newArchEnabled": true,
    "splash": {
      "backgroundColor": "#000000",
      "resizeMode": "contain"
    },
    "ios": {
      "supportsTablet": false,
      "bundleIdentifier": "com.mycompany.myapp"
    },
    "android": {
      "adaptiveIcon": {
        "backgroundColor": "#000000"
      },
      "package": "com.mycompany.myapp"
    },
    "plugins": [
      "expo-font"
    ],
    "scheme": "myapp"
  }
}
```

> **SDK 54 Breaking Change:** `expo-haptics` no longer ships a config plugin. Remove `"expo-haptics"` from the `plugins` array or the build will fail. The package still works at runtime without the plugin.

## Phase 3: Theme System

Use the template at `templates/theme_tokens.ts` as a starting point, then customize colors for your brand.

### 3.1 Design Tokens

Create a centralized token file (`src/lib/theme.ts`) that defines all visual constants. This is the single source of truth for the entire app's appearance. The file exports `Colors`, `Spacing`, `BorderRadius`, `FontSize`, and `FontFamily` objects.

> **SDK 54 / React 19 Type Fix:** The `ThemeColors` type MUST be a union (`typeof Colors.dark | typeof Colors.light`), not just `typeof Colors.dark`. If you only use one branch, TypeScript will reject assignments from `Colors[mode]` when `mode` is `'light'`.

> **Font Availability:** `DMSans_600SemiBold` was removed from `@expo-google-fonts/dm-sans` in recent versions. Use `DMSans_700Bold` as a replacement for semi-bold weights.

### 3.2 Theme Context

The ThemeContext provides `mode`, `colors`, `toggleTheme()`, `setTheme()`, and `isDark` to all components. Wrap the entire app in `<ThemeProvider>` in App.tsx.

### 3.3 Integrating Theme with React Navigation

The `NavigationContainer` accepts a `theme` prop that must be kept in sync with your custom theme. Map your token colors to React Navigation's required color keys (`primary`, `background`, `card`, `text`, `border`, `notification`).

## Phase 4: Navigation Architecture

### 4.1 Type-Safe Navigation

Define a `RootStackParamList` that includes every screen in the app. Add backward-compatibility aliases that point to the same component rather than doing find-and-replace across all files:

```typescript
export type RootStackParamList = {
  Splash: undefined;
  MainTabs: undefined;
  SendGift: undefined;
  // ... all screens
  // Aliases for backward compatibility
  SignIn: undefined;    // → LoginScreen
  Welcome: undefined;   // → OnboardingScreen
};
```

### 4.2 Stack + Bottom Tab Pattern

Nest a `BottomTabNavigator` inside the main `StackNavigator`. This allows feature screens (Send Gift, Event Detail, etc.) to push on top of the tab bar while the tab bar remains accessible from the main screens.

### 4.3 Custom Tab Bar Button

For a prominent center action button (like "Send Gift"), use the `tabBarButton` option to render a custom floating button with shadow and elevation.

## Phase 5: Shared Components

### 5.1 PrimaryButton

A flexible button component that accepts multiple prop naming conventions (`title`, `label`, `text`) to prevent TypeScript errors when different screens use different prop names. The display text resolves as `title ?? label ?? textProp`. Supports `variant` (primary/secondary/outline), `loading`, `disabled`, `icon`, and `children` props.

### 5.2 ScreenHeader

Standardize all screen headers: height 52px, horizontal padding 20px, back icon `arrow-back` size 22, left/right slots 40px wide.

### 5.3 Avatar

Use initials-based avatars instead of external image URLs to avoid broken images and network dependencies. Support `gradient` prop for accent-colored backgrounds.

## Phase 6: App Root Pattern

The root `App.tsx` handles font loading with `useFonts()`, splash screen management with `SplashScreen.preventAutoHideAsync()` / `hideAsync()`, and provider ordering (`ThemeProvider` wraps `NavigationContainer`).

> **Provider Ordering:** `ThemeProvider` must wrap the `NavigationContainer` because navigation theme colors depend on the theme context.

## Phase 7: SDK Migration Guide (SDK 52 → SDK 54)

This section documents every breaking change encountered during a real production migration. Each item caused actual build or runtime failures.

### 7.1 Breaking Changes Summary

| Change | SDK 52 | SDK 54 | Impact |
|--------|--------|--------|--------|
| React version | 18.3.1 | 19.1.0 | Type definitions changed significantly |
| React Native | 0.76.6 | 0.81.5 | New Architecture enabled by default |
| Entry point | `expo-router/entry` | `node_modules/expo/AppEntry.js` | White screen if wrong |
| `@types/react` | `~18.3.12` | `~19.1.10` | Many component types changed |
| `@expo/vector-icons` | `^14.0.0` | `^15.0.3` | Minor API changes |
| `expo-splash-screen` | `~0.29.0` | `~31.0.13` | Major version jump |
| `react-native-reanimated` | `~3.16.0` | `~4.1.1` | Plugin API changes |
| `expo-haptics` plugin | Required in app.json | Removed | Build failure if present |
| `DMSans_600SemiBold` | Available | Removed | Import error |

### 7.2 TypeScript Fixes Required for React 19

1. **Implicit `children` prop removed** — Components must explicitly declare `children: ReactNode`
2. **Event handler types changed** — `TextInput.onFocus` `.clear()` needs `(e.currentTarget as any).clear?.()`
3. **Image source type strictness** — String URIs must use `{ uri: string }` object form
4. **Untyped callback parameters** — Must add explicit types: `(item: typeof menuItems[number]) => ...`
5. **Navigation type casting** — Dynamic targets need `navigation.navigate(item.screen as any)`
6. **Ionicons glyph map typing** — Icon name arrays need `keyof typeof Ionicons.glyphMap` type

### 7.3 Migration Checklist

1. Update `package.json` entry point to `node_modules/expo/AppEntry.js`
2. Run `npx expo install --fix` to auto-resolve compatible versions
3. Update `@types/react` to `~19.1.10`
4. Remove `expo-haptics` from `app.json` plugins array
5. Replace `DMSans_600SemiBold` with `DMSans_700Bold` everywhere
6. Fix `ThemeColors` type to be a union of both theme branches
7. Add explicit types to all callback parameters
8. Wrap string image URIs in `{ uri: ... }` objects
9. Cast dynamic navigation targets with `as any`
10. Type icon name arrays with `keyof typeof Ionicons.glyphMap`
11. Fix `TextInput.onFocus` handlers that call `.clear()`
12. Run `npx tsc --noEmit` and fix remaining errors
13. Test on both iOS and Android simulators

## Phase 8: Common Patterns and Pitfalls

### 8.1 Screen Template

Use the template at `templates/screen_template.tsx` for consistent screen structure. Every screen should use `SafeAreaView`, a status bar spacer (height 48), `ScreenHeader`, and `ScrollView` with `paddingHorizontal: 24`.

### 8.2 UI Consistency Standards

| Element | Value | Notes |
|---------|-------|-------|
| Status bar spacer | `height: 48` | Below SafeAreaView |
| Screen header | `height: 52` | With `paddingHorizontal: 20` |
| Content padding | `paddingHorizontal: 24` | Standard body padding |
| CTA button height | `height: 52` | With `borderRadius: 16` |
| CTA font weight | `fontFamily: bodySemiBold` | Consistent emphasis |
| Back icon | `arrow-back`, size 22 | Ionicons |
| Card border radius | `borderRadius: 16` | Standard card rounding |
| Bottom tab height | `height: 85` | With `paddingBottom: 28` for home indicator |
| Section label style | `uppercase`, `letterSpacing: 2` | For category headers |

### 8.3 Key Pitfalls

- **Never hardcode phone dimensions** (`width: 375, height: 812`) inside screens. Use `flex: 1`.
- **Use `absolute` not `fixed`** positioning. React Native does not support `position: 'fixed'`.
- **Use initials-based avatars** instead of external image URLs to avoid broken images.
- **Centralize mock data** in `src/lib/mockData.ts` with typed constants.
- **Always run `npx tsc --noEmit`** before committing to catch type errors early.

## Phase 9: Coinbase Developer Platform Integration

For fintech apps integrating with Coinbase, use a non-custodial wallet design to avoid money transmitter license requirements (per FinCEN 2019 guidance).

| Integration | Package/API | Purpose |
|-------------|-------------|---------|
| Embedded Wallets | `@coinbase/waas-sdk-react-native` | Non-custodial wallet creation |
| Onramp | Coinbase Onramp API | Fiat → USDC conversion |
| Offramp | Coinbase Offramp API | USDC → fiat cash out |
| Paymaster | ERC-4337 Paymaster | Gasless USDC transfers |
| Base L2 | Base RPC endpoints | Low-cost blockchain transactions |

## Phase 10: Testing and Running

```bash
npx expo start          # Start dev server
npx expo start --ios    # Run on iOS simulator
npx expo start --android # Run on Android emulator
npx tsc --noEmit        # Type check
npx expo start --clear  # Clear cache and restart
```

**Common runtime issues:**
- Blank white screen → Check `package.json` `"main"` field and font loading
- Metro cache issues → `npx expo start --clear` or delete `node_modules/.cache`
- Navigation errors → Verify screen names match `RootStackParamList` exactly

## Resources

- `references/sdk54_dependency_matrix.md` — Complete dependency version matrix with SDK 52 vs 54 comparison
- `references/screen_inventory.md` — Full inventory of 41 screen components organized by navigation flow
- `templates/screen_template.tsx` — Standard screen component template
- `templates/theme_tokens.ts` — Complete theme token template with dark/light modes
